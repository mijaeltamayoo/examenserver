<?php

namespace App\Http\Controllers;

use App\Models\Paciente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class PacienteController extends Controller
{   
    public function index(){
        $paciente = Paciente::all();
        return view('index')->with('paciente',$paciente);
    }
    public function add(Request $request){
        Paciente::create($request->nombre);
        return Redirect::to('/index');
    }

}
