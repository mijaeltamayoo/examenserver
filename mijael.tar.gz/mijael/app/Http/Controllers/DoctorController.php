<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class DoctorController extends Controller
{
    public function add(Request $request){
        $doctor = Doctor::all();
        return view('index')->with('doctor',$doctor);
    }
    public function showLista(){
        return view('listaDoctores')->with('doctor', $doctor);
    }
    public function delete($id){
        $doctor = Doctor::find($id);
        $doctor->delete();
        return Redirect::to('/');
    }
    public function edit($id){
        $doctor = Doctor::find($id);
        return Redirect::to('/');
    }

    public function update(Request $request, $id){
        $doctor = Doctor::find($id);
        $doctor->update([
            'nombre' => $request->nombre,
        ]);
        return Redirect::to('/');
    }
}
