<?php

namespace Database\Seeders;

use App\Models\Doctor;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;


class DoctorPacienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        /*DB::table('doctors')->insert([
            'nombre' => 'Martina',
            'apellidos' => 'Perez',
            'num_paciente' => 2
        ]);*
        
        /*DB::table('pacientes')->insert([
            'nombre' => 'Harry',
            'apellidos' => 'Potter',
            'dni' => 'zx654237',
            'fecha_nacimiento' => '2020-10-03',
            'vacunado' => false,
            'doctor_id' => 2,
        ]);*/
        Doctor::factory(5)->make();
    }
}
