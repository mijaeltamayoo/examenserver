@extends('layout.layout')
@section('content')
    <div>
        <h1>Introducir y Modificar Doctor</h1>
        <form action="/doctor" method="post">
            @csrf 
            <label for="">Nombre: </label>
            <input type="text" name="nombre">
            <label for="">Apellidos: </label>
            <input type="text" name="apellidos">
            <label for="">Pacientes: </label>
            <input type="number" name="num_paciente">
        </form>
        <form action="/doctor/{{ doctor->id }}" method="post">
            @csrf
            method('delete')
            @foreach ($doctores, doctor)
                <ul>
                    <li>{{ doctor->name }}</li>
                    <button type="submit">Eliminar</button>
                    <button><a href="/editar/{doctor->id }"></a>Edit</button>
                </ul>
            @endforeach
        </form>
    </div>
@endsection