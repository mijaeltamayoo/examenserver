@extends('layout.layout')
@section('content')
    <h1>Editar</h1>
    <form action="{{ route('actualizar', [])}}" method="post">
        @csrf
        method('PUT')
        <label for="">Nombre: </label>
        <input type="text" name="nombre" value="{{ doctor->nombre }}">
        <label for="">Apellidos: </label>
        <input type="text" name="apellidos" value="{{ doctor->apellidos }}">
        <label for="">Numero de pacientes: </label>
        <input type="number" value="{{ doctor-> num_paciente }}">
        <button type="submit">Listo</button>
    </form>
@endsection