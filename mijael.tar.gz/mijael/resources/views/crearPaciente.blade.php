@extends('layout.layout')
@section('content')
    <div>
        <form action="/paciente" method="post">
        @csrf
        <h1>Introducir Paciente</h1>
        <label for="">Nombre del paciente:</label>
        <input type="text" name="nombre"><br><br>
        <label for="">Apellidos:</label>
        <input type="text" name="apellidos"><br><br>
        <label for="">DNI: </label>
        <input type="text" name="dni"><br><br>
        <label for="">Fecha Nacimiento: </label>
        <input type="date" name="" id=""><br><br>
        <label for="">Vacunado</label>
        <input type="radio" name="vacunado" value="1">Si
        <input type="radio" name="vacunado" value="">No <br><br>
        <button type="submit">crear paciente</button>
        </form>
    </div>
@endsection