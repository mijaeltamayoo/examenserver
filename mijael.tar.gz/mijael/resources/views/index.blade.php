@extends('layout.layout')
@section('content')
    @include('crearPaciente')
    @include('doctor')
@endsection
